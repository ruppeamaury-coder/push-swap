# push-swap

Deux programmes en Go (bibliothèque standard uniquement) :

- **push-swap** calcule et affiche les instructions qui trient une liste d'entiers avec deux piles `a` et `b` ;
- **checker** lit des instructions sur l'entrée standard, les exécute et affiche `OK` si `a` est triée et `b` vide, `KO` sinon.

## Compiler

Prérequis : Go 1.22 ou plus récent.

Linux / macOS :

```bash
go build -o push-swap ./cmd/push-swap
go build -o checker ./cmd/checker
```

Windows (PowerShell) :

```powershell
go build -o push-swap.exe ./cmd/push-swap
go build -o checker.exe ./cmd/checker
```

## Utiliser

Linux / macOS :

```bash
./push-swap "2 1 3 6 5 8"
ARG="4 67 3 87 23"; ./push-swap "$ARG" | wc -l
ARG="4 67 3 87 23"; ./push-swap "$ARG" | ./checker "$ARG"
echo -e "rra\npb\nsa\nrra\npa" | ./checker "3 2 1 0"
```

Windows (PowerShell) :

```powershell
.\push-swap.exe "2 1 3 6 5 8"
$ARG = "4 67 3 87 23"; (.\push-swap.exe $ARG | Measure-Object -Line).Lines
$ARG = "4 67 3 87 23"; .\push-swap.exe $ARG | .\checker.exe $ARG
"rra","pb","sa","rra","pa" | .\checker.exe "3 2 1 0"
```

Les entiers peuvent être donnés dans un seul argument (`"2 1 3"`) ou dans plusieurs (`2 1 3`). Le premier est le sommet de la pile `a`.

## Tests

```bash
go test ./...        # tous les tests
go test -v ./...     # avec le détail (nombre d'instructions selon la taille)
```

## Organisation du code

```
push-swap/
├── go.mod
├── cmd/
│   ├── push-swap/main.go   programme push-swap
│   └── checker/main.go     programme checker
└── internal/
    ├── stack/              les deux piles, les 11 instructions, la lecture des arguments
    └── solver/             l'algorithme de tri
```

`stack` est partagé par les deux programmes : `checker` exécute les instructions exactement comme `push-swap` les a simulées.

## L'algorithme

1. **Normalisation** : chaque valeur est remplacée par son rang (`42 -7 100` → `1 0 2`). L'ordre reste le même, les calculs sont plus simples.
2. **7 nombres ou moins : recherche en largeur (BFS).** On explore tous les états possibles des deux piles, niveau par niveau. Le premier état trié trouvé est atteint avec **le moins d'instructions possible**. C'est faisable car il y a peu d'états (au plus 40 320 pour 7 nombres).
3. **Plus de 7 nombres : algorithme au moindre coût.**
   - On pousse tous les éléments sauf 3 dans `b`, en gardant `b` triée par ordre décroissant. À chaque étape, on choisit l'élément qui demande le moins de rotations pour être rangé, en combinant `rr` et `rrr` quand les deux piles tournent dans le même sens.
   - On trie les 3 éléments restants dans `a` (2 instructions au plus).
   - On ramène les éléments de `b` dans `a`, toujours en choisissant le moins coûteux.
   - On tourne `a` pour mettre le plus petit au sommet.
4. **Nettoyage** : on supprime les paires qui s'annulent (`ra` puis `rra`, `pb` puis `pa`…) et on fusionne les paires qui ont une instruction double (`ra` + `rb` → `rr`).

## Résultats mesurés

| Nombre d'entiers | Instructions (pire cas mesuré) |
|------------------|--------------------------------|
| 3 | 2 |
| 5 | 8 |
| 6 (`"2 1 3 6 5 8"`) | 7 |
| 100 | ~630 (moyenne ~560) |
| 500 | ~5 250 |

## Gestion des erreurs

`Error` suivi d'un retour à la ligne est affiché sur la sortie d'erreur quand :

- un argument n'est pas un entier (`"0 one 2 3"`, `"1.5"`, nombre trop grand) ;
- un entier est en double ;
- pour `checker`, une instruction n'existe pas ou est mal écrite (`" sa"`, `"SA"`).

Sans argument, les deux programmes n'affichent rien. Les lignes vides et les fins de ligne Windows (`\r\n`) sont acceptées par `checker`.
