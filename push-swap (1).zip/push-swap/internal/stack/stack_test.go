package stack

import (
	"errors"
	"reflect"
	"testing"
)

// Reprend l'exemple du sujet, étape par étape.
func TestExampleFromSubject(t *testing.T) {
	s := New([]int{2, 1, 3, 6, 8, 5})
	steps := []struct {
		ops  []string
		a, b []int
	}{
		{[]string{"sa"}, []int{1, 2, 3, 6, 8, 5}, []int{}},
		{[]string{"pb", "pb", "pb"}, []int{6, 8, 5}, []int{3, 2, 1}},
		{[]string{"rb"}, []int{6, 8, 5}, []int{2, 1, 3}},
		{[]string{"rrr"}, []int{5, 6, 8}, []int{3, 2, 1}},
		{[]string{"pa", "pa", "pa"}, []int{1, 2, 3, 5, 6, 8}, []int{}},
	}
	for _, st := range steps {
		for _, op := range st.ops {
			if err := s.Apply(op); err != nil {
				t.Fatal(err)
			}
		}
		if !reflect.DeepEqual(s.A, st.a) || !reflect.DeepEqual(s.B, st.b) {
			t.Fatalf("après %v : a=%v b=%v, attendu a=%v b=%v", st.ops, s.A, s.B, st.a, st.b)
		}
	}
	if !s.IsDone() {
		t.Error("la pile devrait être triée")
	}
}

func TestEmptyStacksDoNotPanic(t *testing.T) {
	s := New(nil)
	for _, op := range Instructions {
		if err := s.Apply(op); err != nil {
			t.Fatalf("%s : %v", op, err)
		}
	}
}

func TestUnknownInstruction(t *testing.T) {
	s := New([]int{1, 2})
	for _, op := range []string{"", "SA", " sa", "sa ", "rrrr", "p a"} {
		if err := s.Apply(op); err == nil {
			t.Errorf("%q aurait dû être refusée", op)
		}
	}
}

func TestParseArgs(t *testing.T) {
	ok := map[string][]string{
		"un seul argument":    {"2 1 3"},
		"plusieurs arguments": {"2", "1", "3"},
		"espaces en trop":     {"  2   1 3 "},
	}
	for name, args := range ok {
		got, err := ParseArgs(args)
		if err != nil || !reflect.DeepEqual(got, []int{2, 1, 3}) {
			t.Errorf("%s : %v, %v", name, got, err)
		}
	}
	if got, err := ParseArgs([]string{"-5 +3 0"}); err != nil || !reflect.DeepEqual(got, []int{-5, 3, 0}) {
		t.Errorf("signes : %v, %v", got, err)
	}
	if got, err := ParseArgs(nil); err != nil || len(got) != 0 {
		t.Errorf("sans argument : %v, %v", got, err)
	}
	bad := [][]string{{"0 one 2 3"}, {"1 2 1"}, {"1.5"}, {"3", "3"}, {"99999999999999999999"}, {"12a"}}
	for _, args := range bad {
		if _, err := ParseArgs(args); !errors.Is(err, ErrInvalid) {
			t.Errorf("%v aurait dû être refusé", args)
		}
	}
}
