// Package stack contient les deux piles (a et b), les 11 instructions
// et la lecture des arguments. Il est partagé par push-swap et checker.
package stack

import (
	"errors"
	"fmt"
	"strconv"
	"strings"
)

// Instructions liste toutes les instructions autorisées.
var Instructions = []string{"sa", "sb", "ss", "pa", "pb", "ra", "rb", "rr", "rra", "rrb", "rrr"}

// Stacks représente les deux piles. L'indice 0 est le sommet de la pile.
type Stacks struct {
	A []int
	B []int
}

// New crée les piles : a contient une copie des valeurs, b est vide.
func New(values []int) *Stacks {
	return &Stacks{A: append([]int{}, values...), B: []int{}}
}

// Clone renvoie une copie indépendante des deux piles.
func (s *Stacks) Clone() *Stacks {
	return &Stacks{A: append([]int{}, s.A...), B: append([]int{}, s.B...)}
}

// Apply exécute une instruction. Une instruction inconnue renvoie une erreur.
// Une instruction impossible (pile trop petite) ne fait rien.
func (s *Stacks) Apply(op string) error {
	switch op {
	case "sa":
		swap(s.A)
	case "sb":
		swap(s.B)
	case "ss":
		swap(s.A)
		swap(s.B)
	case "pa":
		s.B, s.A = push(s.B, s.A)
	case "pb":
		s.A, s.B = push(s.A, s.B)
	case "ra":
		rotate(s.A)
	case "rb":
		rotate(s.B)
	case "rr":
		rotate(s.A)
		rotate(s.B)
	case "rra":
		reverseRotate(s.A)
	case "rrb":
		reverseRotate(s.B)
	case "rrr":
		reverseRotate(s.A)
		reverseRotate(s.B)
	default:
		return fmt.Errorf("instruction inconnue : %q", op)
	}
	return nil
}

// IsDone indique si a est triée par ordre croissant et b est vide.
func (s *Stacks) IsDone() bool {
	return len(s.B) == 0 && IsSorted(s.A)
}

// IsSorted indique si la tranche est triée par ordre croissant.
func IsSorted(values []int) bool {
	for i := 1; i < len(values); i++ {
		if values[i-1] > values[i] {
			return false
		}
	}
	return true
}

// swap échange les deux premiers éléments.
func swap(x []int) {
	if len(x) >= 2 {
		x[0], x[1] = x[1], x[0]
	}
}

// rotate : le premier élément devient le dernier.
func rotate(x []int) {
	if len(x) >= 2 {
		first := x[0]
		copy(x, x[1:])
		x[len(x)-1] = first
	}
}

// reverseRotate : le dernier élément devient le premier.
func reverseRotate(x []int) {
	if len(x) >= 2 {
		last := x[len(x)-1]
		copy(x[1:], x[:len(x)-1])
		x[0] = last
	}
}

// push déplace le sommet de src vers le sommet de dst et renvoie les deux piles.
func push(src, dst []int) ([]int, []int) {
	if len(src) == 0 {
		return src, dst
	}
	top := src[0]
	src = append(src[:0], src[1:]...)
	dst = append(dst, 0)
	copy(dst[1:], dst[:len(dst)-1])
	dst[0] = top
	return src, dst
}

// ErrInvalid est renvoyée quand un argument n'est pas un entier ou est en double.
var ErrInvalid = errors.New("arguments invalides")

// ParseArgs lit les entiers. Ils peuvent être dans un seul argument ("2 1 3")
// ou dans plusieurs (2 1 3). Le premier entier est le sommet de la pile a.
func ParseArgs(args []string) ([]int, error) {
	fields := strings.Fields(strings.Join(args, " "))
	values := make([]int, 0, len(fields))
	seen := make(map[int]bool, len(fields))
	for _, f := range fields {
		n, err := strconv.Atoi(f)
		if err != nil {
			return nil, fmt.Errorf("%w : %q n'est pas un entier", ErrInvalid, f)
		}
		if seen[n] {
			return nil, fmt.Errorf("%w : %d est en double", ErrInvalid, n)
		}
		seen[n] = true
		values = append(values, n)
	}
	return values, nil
}
