package solver

import (
	"math/rand"
	"testing"

	"pushswap/internal/stack"
)

// sortsCorrectly exécute les instructions comme le ferait checker.
func sortsCorrectly(t *testing.T, values []int, ops []string) {
	t.Helper()
	s := stack.New(values)
	for _, op := range ops {
		if err := s.Apply(op); err != nil {
			t.Fatalf("instruction invalide %q", op)
		}
	}
	if !s.IsDone() {
		t.Fatalf("%v n'est pas trié : a=%v b=%v", values, s.A, s.B)
	}
}

func TestSubjectExamples(t *testing.T) {
	cases := []struct {
		values []int
		max    int
	}{
		{[]int{2, 1, 3, 6, 5, 8}, 7},
		{[]int{4, 67, 3, 87, 23}, 6},
		{[]int{3, 2, 1, 0}, 6},
		{[]int{0, 1, 2, 3, 4, 5}, 0}, // déjà trié
		{[]int{42}, 0},
		{nil, 0},
	}
	for _, c := range cases {
		ops := Solve(c.values)
		sortsCorrectly(t, c.values, ops)
		if len(ops) > c.max {
			t.Errorf("%v : %d instructions, %d au plus attendues", c.values, len(ops), c.max)
		}
	}
}

// Toutes les permutations de 1 à 6 éléments sont triées.
func TestAllSmallPermutations(t *testing.T) {
	for n := 1; n <= 6; n++ {
		perm := make([]int, n)
		for i := range perm {
			perm[i] = i * 10
		}
		var visit func(k int)
		visit = func(k int) {
			if k == n {
				sortsCorrectly(t, perm, Solve(perm))
				return
			}
			for i := k; i < n; i++ {
				perm[k], perm[i] = perm[i], perm[k]
				visit(k + 1)
				perm[k], perm[i] = perm[i], perm[k]
			}
		}
		visit(0)
	}
}

func randomValues(r *rand.Rand, n int) []int {
	perm := r.Perm(n * 10)[:n]
	for i := range perm {
		perm[i] -= n * 5 // des négatifs aussi
	}
	return perm
}

func TestRandomLists(t *testing.T) {
	r := rand.New(rand.NewSource(1))
	for _, c := range []struct{ n, runs, max int }{
		{5, 200, 12},
		{7, 100, 20},
		{8, 100, 30},
		{20, 50, 150},
		{100, 30, 700},
		{500, 5, 5500},
	} {
		worst := 0
		for i := 0; i < c.runs; i++ {
			v := randomValues(r, c.n)
			ops := Solve(v)
			sortsCorrectly(t, v, ops)
			worst = max(worst, len(ops))
		}
		t.Logf("%3d nombres : %4d instructions au pire (sur %d essais)", c.n, worst, c.runs)
		if worst > c.max {
			t.Errorf("%d nombres : %d instructions, plus de %d", c.n, worst, c.max)
		}
	}
}

func TestOptimize(t *testing.T) {
	got := optimize([]string{"ra", "rra", "pb", "pa", "ra", "rb", "sa", "sb"})
	if len(got) != 2 || got[0] != "rr" || got[1] != "ss" {
		t.Errorf("optimize : %v", got)
	}
}
