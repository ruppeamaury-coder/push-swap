// Package solver calcule la liste d'instructions qui trie la pile a.
//
// Stratégie :
//   - 7 nombres ou moins : recherche en largeur (BFS) de toutes les
//     positions possibles. Elle trouve la solution la plus courte possible.
//   - plus de 7 nombres : algorithme « au moindre coût ». À chaque étape,
//     on déplace l'élément qui coûte le moins d'instructions à ranger.
//
// Une dernière passe supprime ou fusionne les instructions inutiles.
package solver

import (
	"sort"

	"pushswap/internal/stack"
)

// bfsLimit : au-delà, la recherche exhaustive devient trop lente.
const bfsLimit = 7

// Solve renvoie les instructions qui trient values (aucune si déjà triée).
func Solve(values []int) []string {
	if len(values) < 2 || stack.IsSorted(values) {
		return nil
	}
	ranks := normalize(values)
	var ops []string
	if len(ranks) <= bfsLimit {
		ops = shortest(ranks)
	} else {
		ops = cheapest(ranks)
	}
	return optimize(ops)
}

// normalize remplace chaque valeur par son rang : [42 -7 100] -> [1 0 2].
// L'ordre est le même, mais les calculs sont plus simples.
func normalize(values []int) []int {
	sorted := append([]int{}, values...)
	sort.Ints(sorted)
	rank := make(map[int]int, len(sorted))
	for i, v := range sorted {
		rank[v] = i
	}
	out := make([]int, len(values))
	for i, v := range values {
		out[i] = rank[v]
	}
	return out
}

// ---------- Petites listes : recherche en largeur ----------

// encode transforme un état des deux piles en clé unique.
func encode(s *stack.Stacks) string {
	b := make([]byte, 0, len(s.A)+len(s.B)+1)
	for _, v := range s.A {
		b = append(b, byte(v))
	}
	b = append(b, '|')
	for _, v := range s.B {
		b = append(b, byte(v))
	}
	return string(b)
}

func decode(key string) *stack.Stacks {
	s := &stack.Stacks{A: []int{}, B: []int{}}
	inB := false
	for i := 0; i < len(key); i++ {
		switch {
		case key[i] == '|':
			inB = true
		case inB:
			s.B = append(s.B, int(key[i]))
		default:
			s.A = append(s.A, int(key[i]))
		}
	}
	return s
}

type step struct {
	prev string
	op   string
}

// shortest explore les états niveau par niveau : le premier état trié
// atteint l'est avec le moins d'instructions possible.
func shortest(ranks []int) []string {
	start := encode(stack.New(ranks))
	parent := map[string]step{start: {}}
	queue := []string{start}
	for len(queue) > 0 {
		key := queue[0]
		queue = queue[1:]
		for _, op := range stack.Instructions {
			next := decode(key)
			next.Apply(op)
			nk := encode(next)
			if _, seen := parent[nk]; seen {
				continue
			}
			parent[nk] = step{prev: key, op: op}
			if next.IsDone() {
				return path(parent, start, nk)
			}
			queue = append(queue, nk)
		}
	}
	return nil // impossible : un état trié est toujours atteignable
}

func path(parent map[string]step, start, end string) []string {
	var ops []string
	for k := end; k != start; k = parent[k].prev {
		ops = append(ops, parent[k].op)
	}
	for i, j := 0, len(ops)-1; i < j; i, j = i+1, j-1 {
		ops[i], ops[j] = ops[j], ops[i]
	}
	return ops
}

// ---------- Grandes listes : algorithme au moindre coût ----------

// recorder applique les instructions et les mémorise.
type recorder struct {
	s   *stack.Stacks
	ops []string
}

func (r *recorder) do(op string, times int) {
	for i := 0; i < times; i++ {
		r.s.Apply(op)
		r.ops = append(r.ops, op)
	}
}

// plan : les rotations à faire avant de pousser un élément d'une pile à l'autre.
// « src » est la pile de départ, « dst » la pile d'arrivée.
type plan struct {
	both, bothRev int // rr, rrr
	src, srcRev   int // rotations de la pile de départ seule
	dst, dstRev   int // rotations de la pile d'arrivée seule
	cost          int
}

// down : nombre de rotations inverses pour amener l'indice i au sommet.
func down(i, length int) int {
	if i == 0 {
		return 0
	}
	return length - i
}

// bestPlan compare les 4 façons d'amener l'élément i (départ) et la cible j
// (arrivée) au sommet, en profitant de rr et rrr quand c'est possible.
func bestPlan(i, srcLen, j, dstLen int) plan {
	di, dj := down(i, srcLen), down(j, dstLen)
	candidates := []plan{
		{both: min(i, j), src: i - min(i, j), dst: j - min(i, j), cost: max(i, j)},
		{bothRev: min(di, dj), srcRev: di - min(di, dj), dstRev: dj - min(di, dj), cost: max(di, dj)},
		{src: i, dstRev: dj, cost: i + dj},
		{srcRev: di, dst: j, cost: di + j},
	}
	best := candidates[0]
	for _, c := range candidates[1:] {
		if c.cost < best.cost {
			best = c
		}
	}
	return best
}

// targetInB : b est gardée en ordre décroissant. v doit se poser au-dessus
// du plus grand élément plus petit que lui (ou au-dessus du maximum).
func targetInB(b []int, v int) int {
	best, maxIdx := -1, 0
	for i, x := range b {
		if x < v && (best == -1 || x > b[best]) {
			best = i
		}
		if x > b[maxIdx] {
			maxIdx = i
		}
	}
	if best == -1 {
		return maxIdx
	}
	return best
}

// targetInA : a est gardée en ordre croissant (à une rotation près). v doit se
// poser au-dessus du plus petit élément plus grand que lui (ou au-dessus du minimum).
func targetInA(a []int, v int) int {
	best, minIdx := -1, 0
	for i, x := range a {
		if x > v && (best == -1 || x < a[best]) {
			best = i
		}
		if x < a[minIdx] {
			minIdx = i
		}
	}
	if best == -1 {
		return minIdx
	}
	return best
}

// move exécute le plan le moins cher puis pousse l'élément.
// toB vaut true pour a -> b, false pour b -> a.
func (r *recorder) move(toB bool) {
	src, dst := r.s.A, r.s.B
	target := targetInB
	if !toB {
		src, dst = r.s.B, r.s.A
		target = targetInA
	}
	var best plan
	for i, v := range src {
		p := bestPlan(i, len(src), target(dst, v), len(dst))
		if i == 0 || p.cost < best.cost {
			best = p
		}
	}
	srcR, srcRR, dstR, dstRR, pushOp := "ra", "rra", "rb", "rrb", "pb"
	if !toB {
		srcR, srcRR, dstR, dstRR, pushOp = "rb", "rrb", "ra", "rra", "pa"
	}
	r.do("rr", best.both)
	r.do("rrr", best.bothRev)
	r.do(srcR, best.src)
	r.do(srcRR, best.srcRev)
	r.do(dstR, best.dst)
	r.do(dstRR, best.dstRev)
	r.do(pushOp, 1)
}

// sortThree trie a quand elle contient exactement 3 éléments (2 instructions au plus).
func (r *recorder) sortThree() {
	a := r.s.A
	switch {
	case a[0] > a[1] && a[0] > a[2]:
		r.do("ra", 1)
	case a[1] > a[0] && a[1] > a[2]:
		r.do("rra", 1)
	}
	if r.s.A[0] > r.s.A[1] {
		r.do("sa", 1)
	}
}

func cheapest(ranks []int) []string {
	r := &recorder{s: stack.New(ranks)}
	// 1. On garde 3 éléments dans a, tout le reste part dans b, rangé.
	for len(r.s.A) > 3 && len(r.s.B) < 2 {
		r.do("pb", 1)
	}
	for len(r.s.A) > 3 {
		r.move(true)
	}
	// 2. On trie les 3 éléments restants.
	r.sortThree()
	// 3. On ramène chaque élément de b à sa place dans a.
	for len(r.s.B) > 0 {
		r.move(false)
	}
	// 4. On tourne a pour mettre le minimum au sommet.
	minIdx := targetInA(r.s.A, len(ranks)) // aucun élément n'est plus grand -> minimum
	if minIdx <= len(r.s.A)/2 {
		r.do("ra", minIdx)
	} else {
		r.do("rra", len(r.s.A)-minIdx)
	}
	return r.ops
}

// ---------- Nettoyage final ----------

var cancels = map[[2]string]bool{
	{"pa", "pb"}: true, {"pb", "pa"}: true,
	{"ra", "rra"}: true, {"rra", "ra"}: true,
	{"rb", "rrb"}: true, {"rrb", "rb"}: true,
	{"rr", "rrr"}: true, {"rrr", "rr"}: true,
	{"sa", "sa"}: true, {"sb", "sb"}: true, {"ss", "ss"}: true,
}

var merges = map[[2]string]string{
	{"ra", "rb"}: "rr", {"rb", "ra"}: "rr",
	{"rra", "rrb"}: "rrr", {"rrb", "rra"}: "rrr",
	{"sa", "sb"}: "ss", {"sb", "sa"}: "ss",
}

// optimize supprime les paires qui s'annulent (ra puis rra…) et fusionne
// les paires qui ont une instruction double (ra puis rb -> rr).
func optimize(ops []string) []string {
	out := make([]string, 0, len(ops))
	for _, op := range ops {
		if n := len(out); n > 0 {
			pair := [2]string{out[n-1], op}
			if cancels[pair] {
				out = out[:n-1]
				continue
			}
			if m, ok := merges[pair]; ok {
				out[n-1] = m
				continue
			}
		}
		out = append(out, op)
	}
	return out
}
