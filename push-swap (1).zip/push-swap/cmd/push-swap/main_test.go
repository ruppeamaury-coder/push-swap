package main

import (
	"bytes"
	"testing"
)

func TestPushSwap(t *testing.T) {
	var out, errOut bytes.Buffer
	if code := run([]string{"2 1 3 6 5 8"}, &out, &errOut); code != 0 || out.String() != "pb\npb\nra\nsa\nrrr\npa\npa\n" {
		t.Errorf("exemple du sujet : code %d, sortie %q", code, out.String())
	}
	out.Reset()
	if code := run([]string{"0 one 2 3"}, &out, &errOut); code != 1 || errOut.String() != "Error\n" || out.Len() != 0 {
		t.Errorf("erreur : code %d, erreur %q", code, errOut.String())
	}
	out.Reset()
	errOut.Reset()
	if code := run(nil, &out, &errOut); code != 0 || out.Len() != 0 || errOut.Len() != 0 {
		t.Error("sans argument, rien ne doit s'afficher")
	}
}
