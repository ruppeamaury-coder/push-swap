// push-swap affiche la liste d'instructions qui trie les entiers reçus en argument.
//
//	./push-swap "2 1 3 6 5 8"
package main

import (
	"bufio"
	"fmt"
	"io"
	"os"

	"pushswap/internal/solver"
	"pushswap/internal/stack"
)

func main() {
	os.Exit(run(os.Args[1:], os.Stdout, os.Stderr))
}

// run est séparée de main pour pouvoir être testée. Elle renvoie le code de sortie.
func run(args []string, stdout, stderr io.Writer) int {
	values, err := stack.ParseArgs(args)
	if err != nil {
		fmt.Fprintln(stderr, "Error")
		return 1
	}
	w := bufio.NewWriter(stdout)
	defer w.Flush()
	for _, op := range solver.Solve(values) {
		fmt.Fprintln(w, op)
	}
	return 0
}
