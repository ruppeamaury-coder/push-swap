package main

import (
	"bytes"
	"strings"
	"testing"
)

func TestChecker(t *testing.T) {
	cases := []struct {
		name, args, stdin, out, errOut string
		code                           int
	}{
		{"pas trié", "3 2 1 0", "sa\nrra\npb\n", "KO\n", "", 0},
		{"trié", "3 2 1 0", "rra\npb\nsa\nrra\npa", "OK\n", "", 0},
		{"déjà trié sans instruction", "1 2 3", "", "OK\n", "", 0},
		{"argument invalide", "3 2 one 0", "rra\npb\nsa\n", "", "Error\n", 1},
		{"doublon", "1 2 2", "", "", "Error\n", 1},
		{"instruction inconnue", "2 1", "sa\nfoo\n", "", "Error\n", 1},
		{"instruction mal formée", "2 1", " sa\n", "", "Error\n", 1},
		{"fin de ligne Windows", "2 1", "sa\r\n", "OK\n", "", 0},
		{"b non vide", "1 2 3", "pb\n", "KO\n", "", 0},
		{"sans argument", "", "sa\n", "", "", 0},
	}
	for _, c := range cases {
		var out, errOut bytes.Buffer
		var args []string
		if c.args != "" {
			args = []string{c.args}
		}
		code := run(args, strings.NewReader(c.stdin), &out, &errOut)
		if code != c.code || out.String() != c.out || errOut.String() != c.errOut {
			t.Errorf("%s : code %d, sortie %q, erreur %q", c.name, code, out.String(), errOut.String())
		}
	}
}
