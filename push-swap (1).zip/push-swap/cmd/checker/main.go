// checker lit des instructions sur l'entrée standard, les exécute sur les
// entiers reçus en argument, puis affiche OK si la pile a est triée et b vide, KO sinon.
//
//	./push-swap "3 2 1 0" | ./checker "3 2 1 0"
package main

import (
	"bufio"
	"fmt"
	"io"
	"os"
	"strings"

	"pushswap/internal/stack"
)

func main() {
	os.Exit(run(os.Args[1:], os.Stdin, os.Stdout, os.Stderr))
}

// run est séparée de main pour pouvoir être testée. Elle renvoie le code de sortie.
func run(args []string, stdin io.Reader, stdout, stderr io.Writer) int {
	values, err := stack.ParseArgs(args)
	if err != nil {
		fmt.Fprintln(stderr, "Error")
		return 1
	}
	if len(values) == 0 {
		return 0 // aucun argument : rien à afficher
	}

	// On lit toutes les instructions avant de les exécuter.
	var ops []string
	sc := bufio.NewScanner(stdin)
	for sc.Scan() {
		line := strings.TrimSuffix(sc.Text(), "\r") // fins de ligne Windows
		if line == "" {
			continue // ligne vide (ex. retour à la ligne final de echo -e)
		}
		ops = append(ops, line)
	}
	if sc.Err() != nil {
		fmt.Fprintln(stderr, "Error")
		return 1
	}

	s := stack.New(values)
	for _, op := range ops {
		if err := s.Apply(op); err != nil {
			fmt.Fprintln(stderr, "Error")
			return 1
		}
	}
	if s.IsDone() {
		fmt.Fprintln(stdout, "OK")
	} else {
		fmt.Fprintln(stdout, "KO")
	}
	return 0
}
