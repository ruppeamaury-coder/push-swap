package stack

import (
	"reflect"
	"testing"
)

func TestExecEachInstruction(t *testing.T) {
	tests := []struct {
		op           string
		a, b         []int
		wantA, wantB []int
	}{
		{"sa", []int{1, 2, 3}, []int{}, []int{2, 1, 3}, []int{}},
		{"sb", []int{}, []int{1, 2}, []int{}, []int{2, 1}},
		{"ss", []int{1, 2}, []int{3, 4}, []int{2, 1}, []int{4, 3}},
		{"pa", []int{1}, []int{2, 3}, []int{2, 1}, []int{3}},
		{"pb", []int{1, 2}, []int{}, []int{2}, []int{1}},
		{"ra", []int{1, 2, 3}, []int{}, []int{2, 3, 1}, []int{}},
		{"rb", []int{}, []int{1, 2, 3}, []int{}, []int{2, 3, 1}},
		{"rr", []int{1, 2}, []int{3, 4}, []int{2, 1}, []int{4, 3}},
		{"rra", []int{1, 2, 3}, []int{}, []int{3, 1, 2}, []int{}},
		{"rrb", []int{}, []int{1, 2, 3}, []int{}, []int{3, 1, 2}},
		{"rrr", []int{1, 2, 3}, []int{4, 5, 6}, []int{3, 1, 2}, []int{6, 4, 5}},
		// instructions on empty or single-element stacks do nothing
		{"pa", []int{1}, []int{}, []int{1}, []int{}},
		{"sa", []int{1}, []int{}, []int{1}, []int{}},
		{"ra", []int{}, []int{}, []int{}, []int{}},
	}

	for _, tt := range tests {
		s := &Stacks{A: tt.a, B: tt.b}
		if err := s.Exec(tt.op); err != nil {
			t.Fatalf("%s: unexpected error %v", tt.op, err)
		}
		if !reflect.DeepEqual(s.A, tt.wantA) || !reflect.DeepEqual(s.B, tt.wantB) {
			t.Errorf("%s: got a=%v b=%v, want a=%v b=%v", tt.op, s.A, s.B, tt.wantA, tt.wantB)
		}
	}
}

func TestExecUnknownInstruction(t *testing.T) {
	s := New([]int{1, 2})
	if err := s.Exec("sx"); err == nil {
		t.Error("expected an error for an unknown instruction")
	}
}

// The example of the subject must end sorted.
func TestSubjectExample(t *testing.T) {
	s := New([]int{2, 1, 3, 6, 8, 5})
	for _, op := range []string{"sa", "pb", "pb", "pb", "rb", "rrr", "pa", "pa", "pa"} {
		if err := s.Exec(op); err != nil {
			t.Fatal(err)
		}
	}
	if !s.IsSorted() {
		t.Errorf("expected sorted stacks, got a=%v b=%v", s.A, s.B)
	}
}

func TestIsSorted(t *testing.T) {
	if !New([]int{1, 2, 3}).IsSorted() {
		t.Error("1 2 3 should be sorted")
	}
	if New([]int{2, 1, 3}).IsSorted() {
		t.Error("2 1 3 should not be sorted")
	}
	if (&Stacks{A: []int{1, 2}, B: []int{3}}).IsSorted() {
		t.Error("stacks with b not empty should not be sorted")
	}
}
