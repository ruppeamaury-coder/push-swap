package stack

import (
	"errors"
	"reflect"
	"strings"
	"testing"
)

func TestParseArgs(t *testing.T) {
	tests := []struct {
		name    string
		args    []string
		want    []int
		wantErr error
	}{
		{"one string", []string{"2 1 3 6 5 8"}, []int{2, 1, 3, 6, 5, 8}, nil},
		{"several args", []string{"3", "-2", "1"}, []int{3, -2, 1}, nil},
		{"extra spaces", []string{"  4   67 3 "}, []int{4, 67, 3}, nil},
		{"empty string", []string{""}, []int{}, nil},
		{"not an integer", []string{"0 one 2 3"}, nil, ErrNotInteger},
		{"float", []string{"1 2.5"}, nil, ErrNotInteger},
		{"overflow", []string{"99999999999999999999"}, nil, ErrNotInteger},
		{"duplicate", []string{"1 2 1"}, nil, ErrDuplicate},
	}

	for _, tt := range tests {
		got, err := ParseArgs(tt.args)
		if !errors.Is(err, tt.wantErr) {
			t.Errorf("%s: error = %v, want %v", tt.name, err, tt.wantErr)
			continue
		}
		if tt.wantErr == nil && !reflect.DeepEqual(got, tt.want) {
			t.Errorf("%s: got %v, want %v", tt.name, got, tt.want)
		}
	}
}

func TestReadInstructions(t *testing.T) {
	got, err := ReadInstructions(strings.NewReader("rra\npb\nsa\n\n"))
	if err != nil {
		t.Fatal(err)
	}
	if want := []string{"rra", "pb", "sa"}; !reflect.DeepEqual(got, want) {
		t.Errorf("got %v, want %v", got, want)
	}

	for _, input := range []string{"sa\nxx\n", "sa \n", "SA\n", "pa pb\n"} {
		if _, err := ReadInstructions(strings.NewReader(input)); err == nil {
			t.Errorf("%q: expected an error", input)
		}
	}
}
