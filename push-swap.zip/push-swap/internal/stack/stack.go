// Package stack implements the two stacks of push-swap and its instruction set.
package stack

import (
	"errors"
	"fmt"
)

// ErrUnknownInstruction is returned when an instruction does not exist.
var ErrUnknownInstruction = errors.New("unknown instruction")

// Instructions lists every instruction of the push-swap language.
var Instructions = []string{"sa", "sb", "ss", "pa", "pb", "ra", "rb", "rr", "rra", "rrb", "rrr"}

// Stacks holds stacks a and b. Index 0 is the top of each stack.
type Stacks struct {
	A []int
	B []int
}

// New returns stacks with a filled with values (first value on top) and b empty.
func New(values []int) *Stacks {
	a := make([]int, len(values))
	copy(a, values)
	return &Stacks{A: a, B: []int{}}
}

// Clone returns a deep copy of the stacks.
func (s *Stacks) Clone() *Stacks {
	a := make([]int, len(s.A))
	b := make([]int, len(s.B))
	copy(a, s.A)
	copy(b, s.B)
	return &Stacks{A: a, B: b}
}

// IsValidInstruction reports whether op belongs to the instruction set.
func IsValidInstruction(op string) bool {
	for _, known := range Instructions {
		if op == known {
			return true
		}
	}
	return false
}

// Exec runs one instruction on the stacks.
func (s *Stacks) Exec(op string) error {
	switch op {
	case "sa":
		swap(s.A)
	case "sb":
		swap(s.B)
	case "ss":
		swap(s.A)
		swap(s.B)
	case "pa":
		push(&s.A, &s.B)
	case "pb":
		push(&s.B, &s.A)
	case "ra":
		rotate(s.A)
	case "rb":
		rotate(s.B)
	case "rr":
		rotate(s.A)
		rotate(s.B)
	case "rra":
		reverseRotate(s.A)
	case "rrb":
		reverseRotate(s.B)
	case "rrr":
		reverseRotate(s.A)
		reverseRotate(s.B)
	default:
		return fmt.Errorf("%w: %q", ErrUnknownInstruction, op)
	}
	return nil
}

// IsSorted reports whether a is in ascending order and b is empty.
func (s *Stacks) IsSorted() bool {
	return len(s.B) == 0 && IsAscending(s.A)
}

// IsAscending reports whether values are in ascending order.
func IsAscending(values []int) bool {
	for i := 1; i < len(values); i++ {
		if values[i-1] > values[i] {
			return false
		}
	}
	return true
}

func swap(s []int) {
	if len(s) >= 2 {
		s[0], s[1] = s[1], s[0]
	}
}

func push(dst, src *[]int) {
	if len(*src) == 0 {
		return
	}
	top := (*src)[0]
	*src = (*src)[1:]
	*dst = append([]int{top}, *dst...)
}

func rotate(s []int) {
	if len(s) >= 2 {
		first := s[0]
		copy(s, s[1:])
		s[len(s)-1] = first
	}
}

func reverseRotate(s []int) {
	if len(s) >= 2 {
		last := s[len(s)-1]
		copy(s[1:], s[:len(s)-1])
		s[0] = last
	}
}
