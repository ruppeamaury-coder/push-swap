package stack

import (
	"bufio"
	"errors"
	"io"
	"strconv"
	"strings"
)

// Errors returned while reading arguments or instructions.
var (
	ErrNotInteger = errors.New("argument is not an integer")
	ErrDuplicate  = errors.New("duplicate argument")
)

// ParseArgs turns the program arguments into integers.
// Arguments can be given as one string ("2 1 3") or as several ones (2 1 3).
func ParseArgs(args []string) ([]int, error) {
	fields := strings.Fields(strings.Join(args, " "))
	values := make([]int, 0, len(fields))
	seen := make(map[int]bool, len(fields))

	for _, field := range fields {
		n, err := strconv.Atoi(field)
		if err != nil {
			return nil, ErrNotInteger
		}
		if seen[n] {
			return nil, ErrDuplicate
		}
		seen[n] = true
		values = append(values, n)
	}
	return values, nil
}

// ReadInstructions reads one instruction per line until EOF.
// Empty lines are ignored; any other unknown line is an error.
func ReadInstructions(r io.Reader) ([]string, error) {
	var ops []string
	scanner := bufio.NewScanner(r)
	for scanner.Scan() {
		line := scanner.Text()
		if line == "" {
			continue
		}
		if !IsValidInstruction(line) {
			return nil, ErrUnknownInstruction
		}
		ops = append(ops, line)
	}
	if err := scanner.Err(); err != nil {
		return nil, err
	}
	return ops, nil
}
