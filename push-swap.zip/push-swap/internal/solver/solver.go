// Package solver computes a short list of push-swap instructions that sorts stack a.
package solver

import (
	"sort"

	"push-swap/internal/stack"
)

// bfsLimit is the largest input size solved with an exhaustive search,
// which guarantees the shortest possible solution.
const bfsLimit = 6

// Solve returns the instructions that sort values in ascending order.
func Solve(values []int) []string {
	if len(values) < 2 || stack.IsAscending(values) {
		return nil
	}
	ranks := normalize(values)
	if len(ranks) <= bfsLimit {
		return shortestPath(ranks)
	}
	return greedySort(ranks)
}

// normalize replaces each value by its rank (0 for the smallest),
// which keeps the algorithms independent of the actual numbers.
func normalize(values []int) []int {
	sorted := make([]int, len(values))
	copy(sorted, values)
	sort.Ints(sorted)

	rank := make(map[int]int, len(sorted))
	for i, v := range sorted {
		rank[v] = i
	}
	ranks := make([]int, len(values))
	for i, v := range values {
		ranks[i] = rank[v]
	}
	return ranks
}
