package solver

import "push-swap/internal/stack"

type link struct {
	parent string
	op     string
}

// shortestPath explores every reachable state breadth-first, so the first
// sorted state found is reached with the minimum number of instructions.
// Only usable on small inputs: the number of states grows factorially.
func shortestPath(ranks []int) []string {
	start := stack.New(ranks)
	startKey := key(start)
	visited := map[string]link{startKey: {}}
	queue := []*stack.Stacks{start}

	for len(queue) > 0 {
		current := queue[0]
		queue = queue[1:]
		currentKey := key(current)

		for _, op := range stack.Instructions {
			next := current.Clone()
			_ = next.Exec(op) // op comes from stack.Instructions, it cannot fail
			nextKey := key(next)
			if _, seen := visited[nextKey]; seen {
				continue
			}
			visited[nextKey] = link{parent: currentKey, op: op}
			if next.IsSorted() {
				return rebuild(visited, nextKey, startKey)
			}
			queue = append(queue, next)
		}
	}
	return nil
}

// key encodes a state as a string so it can be stored in a map.
func key(s *stack.Stacks) string {
	buf := make([]byte, 0, len(s.A)+len(s.B)+1)
	for _, v := range s.A {
		buf = append(buf, byte(v+1))
	}
	buf = append(buf, 0)
	for _, v := range s.B {
		buf = append(buf, byte(v+1))
	}
	return string(buf)
}

// rebuild walks the parent links back from the sorted state to the start.
func rebuild(visited map[string]link, end, start string) []string {
	var ops []string
	for k := end; k != start; k = visited[k].parent {
		ops = append(ops, visited[k].op)
	}
	for i, j := 0, len(ops)-1; i < j; i, j = i+1, j-1 {
		ops[i], ops[j] = ops[j], ops[i]
	}
	return ops
}
