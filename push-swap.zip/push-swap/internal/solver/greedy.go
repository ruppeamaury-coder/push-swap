package solver

import "push-swap/internal/stack"

// sorter applies instructions to the stacks and records them.
type sorter struct {
	s   *stack.Stacks
	ops []string
}

func (st *sorter) do(op string, times int) {
	for i := 0; i < times; i++ {
		_ = st.s.Exec(op)
		st.ops = append(st.ops, op)
	}
}

// move describes the rotations needed before pushing an element.
type move struct {
	ra, rb, rra, rrb int
}

func (m move) cost() int {
	return max(m.ra, m.rb) + max(m.rra, m.rrb)
}

// greedySort works on larger inputs ("Turk" algorithm):
//  1. push everything but 3 elements to b, each time choosing the element
//     that is cheapest to place so that b stays sorted in descending order;
//  2. sort the 3 elements left in a;
//  3. push b back to a, each element landing at its right place;
//  4. rotate a so that the smallest element is on top.
func greedySort(ranks []int) []string {
	st := &sorter{s: stack.New(ranks)}

	for len(st.s.A) > 3 && len(st.s.B) < 2 {
		st.do("pb", 1)
	}
	for len(st.s.A) > 3 {
		st.apply(st.cheapestMove())
		st.do("pb", 1)
	}
	st.sortThree()
	for len(st.s.B) > 0 {
		target := targetInA(st.s.A, st.s.B[0])
		st.rotateA(target)
		st.do("pa", 1)
	}
	st.rotateA(indexOfMin(st.s.A))
	return st.ops
}

// cheapestMove finds the element of a that costs the fewest instructions
// to bring on top of a while its target in b is brought on top of b.
func (st *sorter) cheapestMove() move {
	a, b := st.s.A, st.s.B
	var best move
	bestCost := -1
	for i, v := range a {
		j := targetInB(b, v)
		m := bestRotations(i, len(a), j, len(b))
		if c := m.cost(); bestCost < 0 || c < bestCost {
			best, bestCost = m, c
		}
	}
	return best
}

// bestRotations compares the 4 ways of bringing index i of a and index j of b
// on top, counting rr and rrr as a single instruction.
func bestRotations(i, lenA, j, lenB int) move {
	options := []move{
		{ra: i, rb: j},
		{rra: lenA - i, rrb: lenB - j},
		{ra: i, rrb: lenB - j},
		{rra: lenA - i, rb: j},
	}
	best := options[0]
	for _, m := range options[1:] {
		if m.cost() < best.cost() {
			best = m
		}
	}
	return best
}

func (st *sorter) apply(m move) {
	both := min(m.ra, m.rb)
	st.do("rr", both)
	st.do("ra", m.ra-both)
	st.do("rb", m.rb-both)

	both = min(m.rra, m.rrb)
	st.do("rrr", both)
	st.do("rra", m.rra-both)
	st.do("rrb", m.rrb-both)
}

// rotateA brings index i of a on top using the shortest direction.
func (st *sorter) rotateA(i int) {
	if i <= len(st.s.A)/2 {
		st.do("ra", i)
	} else {
		st.do("rra", len(st.s.A)-i)
	}
}

// sortThree sorts a stack a of at most 3 elements in 2 instructions or fewer.
func (st *sorter) sortThree() {
	a := st.s.A
	if len(a) == 3 {
		switch indexOfMax(a) {
		case 0:
			st.do("ra", 1)
		case 1:
			st.do("rra", 1)
		}
	}
	if len(st.s.A) >= 2 && st.s.A[0] > st.s.A[1] {
		st.do("sa", 1)
	}
}

// targetInB returns the index of the element v must be pushed on top of:
// the largest element smaller than v, or the maximum if there is none.
func targetInB(b []int, v int) int {
	target := -1
	for i, x := range b {
		if x < v && (target < 0 || x > b[target]) {
			target = i
		}
	}
	if target < 0 {
		return indexOfMax(b)
	}
	return target
}

// targetInA returns the index of the element v must be pushed above:
// the smallest element bigger than v, or the minimum if there is none.
func targetInA(a []int, v int) int {
	target := -1
	for i, x := range a {
		if x > v && (target < 0 || x < a[target]) {
			target = i
		}
	}
	if target < 0 {
		return indexOfMin(a)
	}
	return target
}

func indexOfMin(values []int) int {
	idx := 0
	for i, v := range values {
		if v < values[idx] {
			idx = i
		}
	}
	return idx
}

func indexOfMax(values []int) int {
	idx := 0
	for i, v := range values {
		if v > values[idx] {
			idx = i
		}
	}
	return idx
}
