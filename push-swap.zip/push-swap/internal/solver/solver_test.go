package solver

import (
	"math/rand"
	"testing"

	"push-swap/internal/stack"
)

// run applies ops to values and reports whether the result is sorted.
func run(t *testing.T, values []int, ops []string) bool {
	t.Helper()
	s := stack.New(values)
	for _, op := range ops {
		if err := s.Exec(op); err != nil {
			t.Fatalf("invalid instruction %q", op)
		}
	}
	return s.IsSorted()
}

func permutations(values []int) [][]int {
	if len(values) <= 1 {
		return [][]int{append([]int{}, values...)}
	}
	var all [][]int
	for i := range values {
		rest := append(append([]int{}, values[:i]...), values[i+1:]...)
		for _, p := range permutations(rest) {
			all = append(all, append([]int{values[i]}, p...))
		}
	}
	return all
}

func TestAlreadySortedOrTiny(t *testing.T) {
	for _, values := range [][]int{{}, {42}, {0, 1, 2, 3, 4, 5}, {-3, 7, 100}} {
		if ops := Solve(values); len(ops) != 0 {
			t.Errorf("%v: expected no instruction, got %v", values, ops)
		}
	}
}

func TestSubjectExamples(t *testing.T) {
	tests := []struct {
		values []int
		max    int
	}{
		{[]int{2, 1, 3, 6, 5, 8}, 7}, // the subject shows a 7-instruction solution
		{[]int{4, 67, 3, 87, 23}, 6}, // the subject shows 6 lines
	}
	for _, tt := range tests {
		ops := Solve(tt.values)
		if !run(t, tt.values, ops) {
			t.Errorf("%v: not sorted by %v", tt.values, ops)
		}
		if len(ops) > tt.max {
			t.Errorf("%v: %d instructions, want at most %d", tt.values, len(ops), tt.max)
		}
	}
}

// Every permutation of up to 6 elements must be sorted.
func TestAllSmallPermutations(t *testing.T) {
	for n := 2; n <= 6; n++ {
		base := make([]int, n)
		for i := range base {
			base[i] = i * 10
		}
		for _, p := range permutations(base) {
			if ops := Solve(p); !run(t, p, ops) {
				t.Fatalf("%v: not sorted by %v", p, ops)
			}
		}
	}
}

func TestRandomInputs(t *testing.T) {
	rng := rand.New(rand.NewSource(1))
	tests := []struct {
		size, runs, maxOps int
	}{
		{7, 200, 40},
		{20, 50, 150},
		{100, 20, 700},
		{500, 5, 5500},
	}
	for _, tt := range tests {
		worst := 0
		for r := 0; r < tt.runs; r++ {
			values := rng.Perm(tt.size)
			for i := range values {
				values[i] -= tt.size / 2 // include negative numbers
			}
			ops := Solve(values)
			if !run(t, values, ops) {
				t.Fatalf("size %d: not sorted", tt.size)
			}
			worst = max(worst, len(ops))
		}
		if worst > tt.maxOps {
			t.Errorf("size %d: worst case %d instructions, want at most %d", tt.size, worst, tt.maxOps)
		}
		t.Logf("size %d: worst case %d instructions", tt.size, worst)
	}
}
