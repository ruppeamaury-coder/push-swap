// checker reads instructions on stdin, runs them on the integers given as
// arguments and prints OK if stack a ends up sorted with b empty, KO otherwise.
package main

import (
	"fmt"
	"os"

	"push-swap/internal/stack"
)

func main() {
	args := os.Args[1:]
	if len(args) == 0 {
		return
	}

	values, err := stack.ParseArgs(args)
	if err != nil {
		exitError()
	}
	if len(values) == 0 {
		return
	}

	ops, err := stack.ReadInstructions(os.Stdin)
	if err != nil {
		exitError()
	}

	s := stack.New(values)
	for _, op := range ops {
		_ = s.Exec(op) // already validated by ReadInstructions
	}

	if s.IsSorted() {
		fmt.Println("OK")
	} else {
		fmt.Println("KO")
	}
}

func exitError() {
	fmt.Fprintln(os.Stderr, "Error")
	os.Exit(1)
}
