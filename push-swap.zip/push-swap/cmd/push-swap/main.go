// push-swap prints the instructions that sort the integers given as arguments.
package main

import (
	"bufio"
	"fmt"
	"os"

	"push-swap/internal/solver"
	"push-swap/internal/stack"
)

func main() {
	args := os.Args[1:]
	if len(args) == 0 {
		return
	}

	values, err := stack.ParseArgs(args)
	if err != nil {
		fmt.Fprintln(os.Stderr, "Error")
		os.Exit(1)
	}

	out := bufio.NewWriter(os.Stdout)
	defer out.Flush()
	for _, op := range solver.Solve(values) {
		fmt.Fprintln(out, op)
	}
}
